package com.example.mixish

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.mixish.model.FileItem

@Composable
fun FileList(files: List<FileItem>, onItemClick: (FileItem) -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxWidth()) {
        items(files) { file ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
                    .clickable { onItemClick(file) },
                elevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(text = file.displayName, style = MaterialTheme.typography.subtitle1)
                    Text(text = "حجم: ${file.size / 1024} KB", style = MaterialTheme.typography.body2)
                }
            }
        }
    }
}