package com.example.mixish

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.ui.PlayerView

class PlayerActivity : ComponentActivity() {

    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uriString = intent.getStringExtra("uri")
        val isVideo = intent.getBooleanExtra("isVideo", true)
        val mediaUri = if (uriString != null) Uri.parse(uriString) else null

        setContent {
            Scaffold(topBar = {
                TopAppBar(title = { Text("پخش‌کننده") })
            }) { padding ->
                Column(modifier = Modifier.padding(padding)) {
                    if (mediaUri != null) {
                        PlayerScreen(mediaUri, isVideo)
                    } else {
                        Text("خطا: فایل پیدا نشد", modifier = Modifier.padding(16.dp))
                    }
                }
            }
        }
    }

    @Composable
    fun PlayerScreen(uri: Uri, isVideo: Boolean) {
        var exoPlayer by remember { mutableStateOf<ExoPlayer?>(null) }

        DisposableEffect(Unit) {
            val playerInstance = ExoPlayer.Builder(this@PlayerActivity).build().also { player ->
                player.setMediaItem(MediaItem.fromUri(uri))
                player.prepare()
                player.play()
            }
            exoPlayer = playerInstance

            onDispose {
                playerInstance.release()
            }
        }

        if (isVideo && exoPlayer != null) {
            AndroidView(factory = { context ->
                PlayerView(context).apply {
                    player = exoPlayer
                    useController = true
                }
            }, modifier = Modifier
                .fillMaxWidth()
                .height(300.dp))
        }
    }
}