package com.example.mixish.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mixish.data.FileRepository
import com.example.mixish.model.FileItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class FileViewModel(application: Application): AndroidViewModel(application) {
    private val repo = FileRepository(application.applicationContext)

    private val _videoFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val videoFiles: StateFlow<List<FileItem>> = _videoFiles

    private val _audioFiles = MutableStateFlow<List<FileItem>>(emptyList())
    val audioFiles: StateFlow<List<FileItem>> = _audioFiles

    fun loadVideos() {
        viewModelScope.launch {
            val list = repo.queryMediaFiles(FileRepository.MediaType.VIDEO, limit = 1000)
            _videoFiles.value = list
        }
    }

    fun loadAudios() {
        viewModelScope.launch {
            val list = repo.queryMediaFiles(FileRepository.MediaType.AUDIO, limit = 1000)
            _audioFiles.value = list
        }
    }
}