package com.example.mixish.model

import android.net.Uri

data class FileItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val size: Long,
    val mimeType: String,
    val dateModified: Long,
    val isVideo: Boolean
)