package com.example.mixish.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.example.mixish.model.FileItem

class FileRepository(private val context: Context) {

    suspend fun queryMediaFiles(type: MediaType, limit: Int = 500): List<FileItem> {
        val result = mutableListOf<FileItem>()
        val resolver = context.contentResolver

        val (collection, projection) = when (type) {
            MediaType.VIDEO -> Pair(
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL),
                arrayOf(
                    MediaStore.Video.Media._ID,
                    MediaStore.Video.Media.DISPLAY_NAME,
                    MediaStore.Video.Media.SIZE,
                    MediaStore.Video.Media.MIME_TYPE,
                    MediaStore.Video.Media.DATE_MODIFIED
                )
            )
            MediaType.AUDIO -> Pair(
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL),
                arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.SIZE,
                    MediaStore.Audio.Media.MIME_TYPE,
                    MediaStore.Audio.Media.DATE_MODIFIED
                )
            )
        }

        val sortOrder = "${MediaStore.MediaColumns.DATE_MODIFIED} DESC LIMIT $limit"

        resolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val nameCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val dateCol = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED)

            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                val displayName = cursor.getString(nameCol) ?: "unknown"
                val size = cursor.getLong(sizeCol)
                val mime = cursor.getString(mimeCol) ?: ""
                val date = cursor.getLong(dateCol)
                val contentUri: Uri = ContentUris.withAppendedId(collection, id)

                result.add(
                    FileItem(
                        id = id,
                        uri = contentUri,
                        displayName = displayName,
                        size = size,
                        mimeType = mime,
                        dateModified = date,
                        isVideo = (type == MediaType.VIDEO)
                    )
                )
            }
        }

        return result
    }

    enum class MediaType { VIDEO, AUDIO }
}