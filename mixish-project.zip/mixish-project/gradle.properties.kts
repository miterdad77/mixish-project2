org.gradle.jvmargs=-Xmx1536m
android.useAndroidX=true
kotlin.code.style=official